"""
Tally: OpenClaw Skill
Physical API Key for Agent Commerce

Exposes 3 tools to any OpenClaw-compatible agent:
  1. request_funding(): Pause agent, notify user, wait for card-tap authorization
  2. check_session_balance(): Query session wallet USDC/SOL balance on-chain
  3. return_funds(): Sweep remaining session funds back to master vault

Architecture:
  Agent (local) → This Skill → Telegram Bot → Deep Link → Mobile App → NFC Tap → Signed Tx

Session wallet key flow (secure):
  1. The MOBILE APP generates the ephemeral session keypair after the card tap
  2. The mobile funds the keypair and stores it locally for the panic sweep
  3. The Auth success screen shows the pubkey and private key ONE TIME
     so the user can copy them into the agent's config manually
  4. No private key is ever sent automatically, the user decides if and how
     to hand it to the agent (paste into terminal, env var, config file, etc.)
  5. The agent polls on-chain for balance; once funded it receives the pubkey
     and can start spending using the private key the user provided

This keeps the Tally app completely clean, it never transmits private keys.
"""

import os
import json
import time
import asyncio
import logging
import base64
import struct
import requests  # pip install requests
from pathlib import Path
from dataclasses import dataclass, asdict, field
from typing import Optional

import base64
import os
from pathlib import Path

from solders.keypair import Keypair as SoldersKeypair  # type: ignore
from solders.pubkey import Pubkey  # type: ignore
from solana.rpc.api import Client as SolanaClient
from solana.rpc.commitment import Confirmed
from solana.rpc.types import TokenAccountOpts

# Auto-load .env (same directory) without requiring python-dotenv
_env_file = Path(__file__).parent / ".env"
if _env_file.exists():
    for _line in _env_file.read_text().splitlines():
        _line = _line.strip()
        if _line and not _line.startswith("#") and "=" in _line:
            _k, _, _v = _line.partition("=")
            os.environ.setdefault(_k.strip(), _v.strip())

from tg_bot import send_funding_request, send_payment_received, send_return_confirmation, send_authorize_budget

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
RPC_URL = os.getenv("TALLY_RPC_URL", "https://api.devnet.solana.com")
USDC_MINT_DEVNET  = "4zMMC9srt5Ri5X14GAgXhaHii3GnPAEERYPJgZJDncDU"
USDC_MINT_MAINNET = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
# Automatically picks the right mint based on which RPC is configured
IS_DEVNET = "devnet" in RPC_URL.lower() or "dev." in RPC_URL.lower()
USDC_MINT = USDC_MINT_DEVNET if IS_DEVNET else USDC_MINT_MAINNET
MAX_SESSION_USDC = float(os.getenv("TALLY_MAX_SESSION", "50.0"))
POLL_INTERVAL = int(os.getenv("TALLY_POLL_INTERVAL", "3"))
POLL_TIMEOUT = int(os.getenv("TALLY_POLL_TIMEOUT", "120"))
VAULT_PUBKEY = os.getenv("TALLY_VAULT_PUBKEY", "").strip()

# Time-bounded policy taps: a card tap can authorize a budget that the agent
# may reuse across calls for a TTL window. Bounds mirror the wallet-side
# values in `src/utils/sessionPolicy.ts`.
MIN_TTL_SECONDS = 60
MAX_TTL_SECONDS = 24 * 60 * 60

# SOL gas management
# Each Solana transaction costs ~5000 lamports (0.000005 SOL).
# We warn when below 0.002 SOL (~400 txs left) and top-up to 0.005 SOL.
SOL_GAS_WARNING_THRESHOLD = float(os.getenv("TALLY_GAS_WARNING", "0.002"))  # SOL
SOL_GAS_TOPUP_TARGET      = float(os.getenv("TALLY_GAS_TOPUP",   "0.005"))  # SOL

log = logging.getLogger("warm-vault")
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(name)s] %(message)s")

solana = SolanaClient(RPC_URL)


# ---------------------------------------------------------------------------
# Data Models
# ---------------------------------------------------------------------------
@dataclass
class SessionWallet:
    """Ephemeral keypair generated per funding session."""
    pubkey: str
    secret_key_bytes: bytes = field(repr=False)
    funded_amount: float = 0.0
    currency: str = "USDC"
    task_description: str = ""
    created_at: float = field(default_factory=time.time)
    # Absolute expiry (unix seconds) when funded via a time-bounded policy tap.
    # None for sessions with no TTL, those never time-expire and behave the
    # same as sessions created before this field existed.
    expires_at: Optional[float] = None


def _validate_ttl(ttl: Optional[int]) -> Optional[int]:
    """
    Bounds-check a TTL argument. Mirrors `parseTtlSeconds` on the wallet side:
    return None for absent, non-int, or out-of-range values rather than
    raising, so a bad TTL silently degrades to "no expiry" instead of
    blocking the whole funding call.
    """
    if ttl is None:
        return None
    if not isinstance(ttl, int) or isinstance(ttl, bool):
        return None
    if ttl < MIN_TTL_SECONDS or ttl > MAX_TTL_SECONDS:
        return None
    return ttl


def is_session_active(session: SessionWallet, now: Optional[float] = None) -> bool:
    """
    True if the session is still within its policy-tap window, or if it has
    no expiry set (legacy mode). False once the deadline has passed. Use this
    in agent loops to decide whether to re-tap or keep reusing the existing
    session.

    Example:
        session = request_funding(amount_usdc=2.0, task_description="x402 calls", ttl=3600)
        while work_remaining():
            if not is_session_active(session):
                session = request_funding(amount_usdc=2.0, task_description="x402 calls", ttl=3600)
            do_one_call(session)
    """
    if session.expires_at is None:
        return True
    return (now if now is not None else time.time()) < session.expires_at


# ---------------------------------------------------------------------------
# EV Engine: Probabilistic Funding (PRD v1.1 FR5)
# ---------------------------------------------------------------------------
class EVEngine:
    """
    Risk-Adjusted Refuelling logic.
    Decides whether the agent should request a lump-sum or just-in-time funding.

    Rules:
      - If avg_cost * n_operations < threshold → lump-sum (fewer taps)
      - If single operation > threshold → JIT (require explicit approval)
      - Never exceed MAX_SESSION_USDC
    """

    LUMP_SUM_THRESHOLD = 5.0   # USDC, below this, batch into one request
    JIT_THRESHOLD = 20.0       # USDC, above this per-op, force individual approval

    @staticmethod
    def calculate_request(
        estimated_ops: int,
        avg_cost_per_op: float,
        risk_score: float = 0.5,
    ) -> dict:
        """
        Returns a funding recommendation.

        Args:
            estimated_ops: Number of operations the agent plans to execute.
            avg_cost_per_op: Average USDC cost per operation.
            risk_score: 0.0 (safe) to 1.0 (risky). Adjusts buffer.

        Returns:
            dict with 'strategy', 'amount', and 'reason'.
        """
        total_ev = estimated_ops * avg_cost_per_op
        buffer = 1.0 + (risk_score * 0.3)  # 0–30% buffer based on risk
        requested = round(total_ev * buffer, 2)

        # Cap at session max
        requested = min(requested, MAX_SESSION_USDC)

        if avg_cost_per_op > EVEngine.JIT_THRESHOLD:
            return {
                "strategy": "JIT",
                "amount": round(avg_cost_per_op * buffer, 2),
                "reason": f"High-value operation (${avg_cost_per_op}/op). Requesting per-operation approval.",
            }

        if total_ev < EVEngine.LUMP_SUM_THRESHOLD:
            return {
                "strategy": "LUMP_SUM",
                "amount": requested,
                "reason": f"Low total EV (${total_ev}). Batching {estimated_ops} ops into single tap.",
            }

        return {
            "strategy": "LUMP_SUM",
            "amount": requested,
            "reason": f"Standard batch: {estimated_ops} ops × ${avg_cost_per_op}/op + {int(risk_score*30)}% buffer.",
        }


# ---------------------------------------------------------------------------
# Tool 1: request_funding
# ---------------------------------------------------------------------------
def request_funding(
    amount_usdc: float,
    task_description: str,
    estimated_ops: int = 1,
    avg_cost_per_op: float = 0.0,
    risk_score: float = 0.5,
    ttl: Optional[int] = None,
) -> SessionWallet:
    """
    Pause the agent, generate an ephemeral session wallet, send a Telegram
    notification to the user, and poll until the session wallet is funded.

    If estimated_ops and avg_cost_per_op are provided, the EV Engine overrides
    the raw amount_usdc with a risk-adjusted recommendation.

    Args:
        amount_usdc: Requested USDC amount (may be overridden by EV engine).
        task_description: Human-readable reason for the funding request.
        estimated_ops: Number of planned operations (for EV calculation).
        avg_cost_per_op: Average cost per operation in USDC.
        risk_score: Risk factor 0.0–1.0.
        ttl: Optional time-bounded policy tap window, in seconds (60s to 24h).
            When set and valid, the card tap authorizes the budget for that
            window and the agent may reuse the returned session across calls
            until `is_session_active(session)` flips to False. Out-of-range
            or non-int values silently degrade to no TTL.

    Returns:
        SessionWallet with the funded ephemeral keypair.

    Raises:
        TimeoutError: If the user doesn't authorize within POLL_TIMEOUT seconds.
        ValueError: If the requested amount exceeds MAX_SESSION_USDC.
    """

    # --- EV Engine override ---
    if estimated_ops > 1 and avg_cost_per_op > 0:
        ev_result = EVEngine.calculate_request(estimated_ops, avg_cost_per_op, risk_score)
        amount_usdc = ev_result["amount"]
        log.info(f"EV Engine: {ev_result['strategy']}, {ev_result['reason']}")

    if amount_usdc > MAX_SESSION_USDC:
        raise ValueError(
            f"Requested ${amount_usdc} exceeds session cap of ${MAX_SESSION_USDC}. "
            f"Break the task into smaller chunks."
        )

    # --- Load session keypair from user-provided env var ---
    # The user creates the session wallet in the Tally mobile app first,
    # then pastes the base58 private key into TALLY_SESSION_SK in .env.
    # This ensures the Tally app is the single source of truth for the session
    # keypair: no key is ever generated by or transmitted through the agent.
    session_sk_b58 = os.getenv("TALLY_SESSION_SK", "").strip()
    if not session_sk_b58:
        raise ValueError(
            "TALLY_SESSION_SK is not set in .env. "
            "Open the Tally app, generate a session keypair, and paste "
            "the base58 private key into TALLY_SESSION_SK."
        )

    try:
        raw_sk = base64.urlsafe_b64decode(session_sk_b58 + "==")
        session_kp = SoldersKeypair.from_seed(raw_sk[:32])
    except Exception as e:
        raise ValueError(
            f"Failed to parse TALLY_SESSION_SK: {e}. "
            "Make sure you pasted the complete private key from the Tally app."
        )

    session_pubkey = str(session_kp.pubkey())
    session_secret_bytes = bytes(session_kp)

    log.info(f"Session wallet loaded: {session_pubkey}")
    log.info("Awaiting card tap authorization...")

    # --- Send Telegram notification with the pre-funded pubkey ---
    # The deep link carries: amount, currency, task, pubkey, and (optionally)
    # ttl for a time-bounded policy tap. User taps card → Tally app broadcasts
    # tx funding this exact pubkey and stores the matching expiresAt on the
    # session record. The agent already holds the matching SK from
    # TALLY_SESSION_SK.
    ttl_validated = _validate_ttl(ttl)
    send_funding_request(
        amount=amount_usdc,
        currency="USDC",
        pubkey=session_pubkey,
        task_description=task_description,
        ttl=ttl_validated,
    )

    # --- Poll on-chain until the session wallet is funded ---
    log.info(f"Polling for funding (timeout: {POLL_TIMEOUT}s)...")
    funded, tx_sig = _poll_for_funding(session_pubkey, amount_usdc)

    if not funded:
        raise TimeoutError(
            f"Authorization timed out after {POLL_TIMEOUT}s. "
            f"Session wallet {session_pubkey[:8]}... was not funded."
        )

    log.info(f"✅ Session funded: {amount_usdc} USDC → {session_pubkey[:8]}...")

    # Notify user that payment was received
    send_payment_received(
        amount=amount_usdc,
        currency="USDC",
        session_pubkey=session_pubkey,
        tx_signature=tx_sig,
    )

    # Stamp the policy-tap window. We anchor expires_at to the moment the
    # funding tx confirmed locally rather than tap time so the agent never
    # under-reports the remaining window (which could otherwise expire here
    # before the agent even gets the session back).
    expires_at = (time.time() + ttl_validated) if ttl_validated is not None else None
    if ttl_validated is not None:
        log.info(f"⏱  Policy tap window: {ttl_validated}s (expires_at={expires_at:.0f})")

    return SessionWallet(
        pubkey=session_pubkey,
        secret_key_bytes=session_secret_bytes,
        funded_amount=amount_usdc,
        currency="USDC",
        task_description=task_description,
        expires_at=expires_at,
    )


# ---------------------------------------------------------------------------
# Tool 2: check_session_balance
# ---------------------------------------------------------------------------
def check_session_balance(session_pubkey: str) -> dict:
    """
    Query on-chain balance of a session wallet.

    Args:
        session_pubkey: The public key of the session wallet.

    Returns:
        dict with 'sol', 'usdc' balances, and 'gas_low' flag.
    """
    try:
        sol_resp = solana.get_balance(Pubkey.from_string(session_pubkey), commitment=Confirmed)
        sol_balance = (sol_resp.value or 0) / 1e9

        usdc_balance = _get_token_balance(session_pubkey, USDC_MINT)

        return {
            "pubkey": session_pubkey,
            "sol": round(sol_balance, 6),
            "usdc": round(usdc_balance, 6),
            # Warn agent when SOL gas is running low so it can act before hitting 0
            "gas_low": sol_balance < SOL_GAS_WARNING_THRESHOLD,
        }
    except Exception as e:
        log.error(f"Balance check failed: {e}")
        return {"pubkey": session_pubkey, "sol": 0.0, "usdc": 0.0, "gas_low": True, "error": str(e)}


# ---------------------------------------------------------------------------
# Tool 3: return_funds
# ---------------------------------------------------------------------------
def return_funds(session: SessionWallet, master_vault_pubkey: str = "") -> str:
    """
    Sweep all remaining funds from the session wallet back to the master vault.
    This should be called when the agent's task is complete.

    Args:
        session: The SessionWallet to sweep from.
        master_vault_pubkey: The master vault's public key (destination).
            Defaults to TALLY_VAULT_PUBKEY from the environment if not provided.

    Returns:
        Transaction signature string, or "no_funds" if balance is zero.
    """
    # Resolve vault destination: explicit arg → TALLY_VAULT_PUBKEY env var
    dest = master_vault_pubkey.strip() or VAULT_PUBKEY
    if not dest:
        raise ValueError(
            "master_vault_pubkey not provided and TALLY_VAULT_PUBKEY is not set in .env"
        )

    balance = check_session_balance(session.pubkey)

    if balance["usdc"] <= 0 and balance["sol"] <= 0:
        log.info("Session wallet is empty. Nothing to sweep.")
        send_return_confirmation(session.pubkey, 0.0, "no_funds")
        return "no_funds"

    try:
        # Reconstruct keypair from stored bytes
        session_kp = SoldersKeypair.from_bytes(session.secret_key_bytes)
        from solders.pubkey import Pubkey  # type: ignore

        master_pubkey = Pubkey.from_string(dest)
        session_pubkey = session_kp.pubkey()

        # 1. Sweep USDC if exists
        if balance["usdc"] > 0:
            log.info(f"Sweeping {balance['usdc']} USDC back to master vault...")
            # Note: In a production app, we'd use get_associated_token_address.
            # For the hackathon skill, we'll find the session's USDC account and transfer to master's USDC account.
            try:
                # Find session's USDC account
                accounts = solana.get_token_accounts_by_owner_json_parsed(
                    session_pubkey,
                    opts=TokenAccountOpts(mint=Pubkey.from_string(USDC_MINT)),
                ).value

                if accounts:
                    session_usdc_ata = accounts[0].pubkey

                    # For master, we assume master has an ATA for USDC.
                    # We can use get_token_accounts_by_owner for master too or just derive it.
                    master_accounts = solana.get_token_accounts_by_owner_json_parsed(
                        master_pubkey,
                        opts=TokenAccountOpts(mint=Pubkey.from_string(USDC_MINT)),
                    ).value
                    
                    if master_accounts:
                        master_usdc_ata = master_accounts[0].pubkey
                        
                        # Construct Transfer instruction manually using bytes if spl-token is missing
                        # Build USDC transfer the same way as run_spend_test.py
                        from solders.instruction import AccountMeta, Instruction
                        from solders.message import Message
                        from solders.transaction import Transaction as SoldersTransaction
                        from solana.rpc.types import TxOpts

                        amount_raw = int(balance["usdc"] * 1e6)  # USDC = 6 decimals
                        data = struct.pack("<BQ", 3, amount_raw)
                        transfer_ix = Instruction(
                            program_id=Pubkey.from_string("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"),
                            accounts=[
                                AccountMeta(session_usdc_ata, is_signer=False, is_writable=True),
                                AccountMeta(master_usdc_ata, is_signer=False, is_writable=True),
                                AccountMeta(session_pubkey, is_signer=True, is_writable=False),
                            ],
                            data=data,
                        )
                        recent = solana.get_latest_blockhash(commitment=Confirmed)
                        msg = Message.new_with_blockhash([transfer_ix], session_pubkey, recent.value.blockhash)
                        tx = SoldersTransaction.new_unsigned(msg)
                        tx.sign([session_kp], recent.value.blockhash)
                        resp = solana.send_transaction(tx, opts=TxOpts(skip_preflight=True))
                        usdc_sig = str(resp.value)
                        log.info(f"✅ Swept {balance['usdc']} USDC back | sig: {usdc_sig}")
            except Exception as e:
                log.error(f"USDC sweep failed: {e}")

        # 2. Sweep SOL back
        if balance["sol"] > 0.001:  # Keep dust for rent
            from solders.system_program import TransferParams, transfer as sol_transfer
            from solders.message import Message
            from solders.transaction import Transaction as SoldersTransaction
            from solana.rpc.types import TxOpts

            sweep_amount = int((balance["sol"] - 0.001) * 1e9)  # Leave 0.001 SOL for fees

            sol_ix = sol_transfer(TransferParams(
                from_pubkey=session_pubkey,
                to_pubkey=master_pubkey,
                lamports=sweep_amount,
            ))
            recent = solana.get_latest_blockhash(commitment=Confirmed)
            msg = Message.new_with_blockhash([sol_ix], session_pubkey, recent.value.blockhash)
            tx = SoldersTransaction.new_unsigned(msg)
            tx.sign([session_kp], recent.value.blockhash)
            resp = solana.send_transaction(tx, opts=TxOpts(skip_preflight=True))
            sig = str(resp.value)
            log.info(f"✅ Swept {balance['sol']:.4f} SOL back → {master_vault_pubkey[:8]}... | sig: {sig}")
            send_return_confirmation(session.pubkey, balance["sol"], sig)
            return sig

        return "no_funds"

    except Exception as e:
        log.error(f"Sweep failed: {e}")
        raise


# ---------------------------------------------------------------------------
# Tool 4: monitor_session
# ---------------------------------------------------------------------------
async def monitor_session(session_pubkey: str, threshold_usdc: float = 2.0):
    """
    Background-friendly monitor that checks the session balance.
    If it falls below the threshold, it sends a 'Refuel' heartbeat via Telegram.

    Args:
        session_pubkey: The public key of the session wallet.
        threshold_usdc: Trigger heartbeat if balance is below this amount.
    """
    from tg_bot import send_heartbeat
    
    balance = await asyncio.to_thread(check_session_balance, session_pubkey)
    usdc = balance.get("usdc", 0.0)
    
    if usdc < threshold_usdc:
        log.warning(f"Session {session_pubkey[:8]} balance low: {usdc} USDC. Sending heartbeat...")
        send_heartbeat(session_pubkey, usdc, "USDC")
        return True
    
    return False


# ---------------------------------------------------------------------------
# Tool 5: ensure_gas
# ---------------------------------------------------------------------------
def ensure_gas(session: SessionWallet) -> dict:
    """
    Ensure the session wallet has enough SOL to pay transaction fees.
    Call this before any on-chain operation, it's a no-op if gas is fine.

    Strategy (in order):
      1. SOL balance is above threshold → return immediately, nothing to do.
      2. Mainnet + session has USDC → auto-swap ~$1 of USDC→SOL via Jupiter.
         The agent funds its own gas from its existing USDC budget, no user
         tap required. Jupiter's quote API prices the swap correctly at runtime.
      3. Devnet, or Jupiter failed → send a Telegram deep-link notification
         asking the user to authorize a small SOL top-up via card tap.
         Same card-tap flow as initial funding, just for a tiny SOL amount.

    Note on the Jupiter "gasless" trick:
      Jupiter's swap transaction sets the *fee payer* to Jupiter's own relayer
      when using their hosted swap endpoint, meaning the fee is deducted from
      the swap output rather than requiring the user to pre-hold SOL. This is
      why swapping USDC→SOL works even when the session wallet has ~0 SOL.
      On devnet Jupiter has no liquidity pools, so this path always falls through
      to option 3.

    Args:
        session: The active SessionWallet.

    Returns:
        dict with 'action' ('none' | 'swapped' | 'requested'),
        'sol_before', 'sol_after', and optional 'signature' / 'error'.
    """
    balance = check_session_balance(session.pubkey)
    sol_before = balance["sol"]

    if not balance["gas_low"]:
        return {"action": "none", "sol_before": sol_before, "sol_after": sol_before}

    log.warning(
        f"⛽ Gas low: {sol_before:.6f} SOL in session {session.pubkey[:8]}… "
        f"(threshold: {SOL_GAS_WARNING_THRESHOLD} SOL). Attempting top-up…"
    )

    # ── Option A: Jupiter USDC→SOL (mainnet only) ───────────────────────────
    if not IS_DEVNET and balance["usdc"] >= 0.1:
        sig = _jupiter_swap_usdc_to_sol(session, amount_usdc=2.0)
        if sig and not sig.startswith("error"):
            new_sol = (solana.get_balance(Pubkey.from_string(session.pubkey), commitment=Confirmed).value or 0) / 1e9
            log.info(f"✅ Gas self-funded via Jupiter swap: {sol_before:.6f} → {new_sol:.6f} SOL")
            return {"action": "swapped", "sol_before": sol_before, "sol_after": new_sol, "signature": sig}
        log.warning(f"Jupiter swap failed ({sig}). Falling back to user request.")

    # ── Option B: request SOL from user via existing Telegram/card-tap flow ─
    topup_needed = round(SOL_GAS_TOPUP_TARGET - sol_before, 6)
    log.info(f"Requesting {topup_needed:.4f} SOL gas top-up from user via Telegram…")

    send_funding_request(
        amount=topup_needed,
        currency="SOL",
        pubkey=session.pubkey,
        task_description=(
            f"⛽ Gas top-up: session {session.pubkey[:8]}… "
            f"has only {sol_before:.5f} SOL left for transaction fees."
        ),
    )

    start = time.time()
    while time.time() - start < POLL_TIMEOUT:
        new_sol = (solana.get_balance(Pubkey.from_string(session.pubkey), commitment=Confirmed).value or 0) / 1e9
        if new_sol >= SOL_GAS_WARNING_THRESHOLD:
            log.info(f"✅ Gas topped up via user tap: {sol_before:.6f} → {new_sol:.6f} SOL")
            return {"action": "requested", "sol_before": sol_before, "sol_after": new_sol}
        time.sleep(POLL_INTERVAL)

    log.warning("Gas top-up timed out, agent may hit fee errors on next transaction.")
    return {
        "action": "requested",
        "sol_before": sol_before,
        "sol_after": sol_before,
        "error": "timeout: user did not authorize the top-up in time",
    }


# ---------------------------------------------------------------------------
# Internal Helpers
# ---------------------------------------------------------------------------
def _jupiter_swap_usdc_to_sol(session: SessionWallet, amount_usdc: float = 1.0) -> str:
    """
    Swap a fixed USDC amount → SOL via Jupiter v6 (mainnet only).
    Returns the transaction signature, or an "error: ..." string on failure.

    Jupiter's fee relayer pays the on-chain fee and deducts it from the output,
    so this works even when the session wallet has near-zero SOL.
    """
    USDC_MINT_MAINNET = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
    WSOL_MINT = "So11111111111111111111111111111111111111112"

    try:
        session_kp = SoldersKeypair.from_bytes(session.secret_key_bytes)
        user_pubkey = str(session_kp.pubkey())

        # 1. Quote
        quote_resp = requests.get(
            "https://api.jup.ag/swap/v1/quote",
            params={
                "inputMint":   USDC_MINT_MAINNET,
                "outputMint":  WSOL_MINT,
                "amount":      str(int(amount_usdc * 1_000_000)),  # 6 decimals
                "slippageBps": "100",   # wider slippage, better route availability
                "maxAccounts": "64",
            },
            timeout=10,
        )
        quote_resp.raise_for_status()
        quote = quote_resp.json()
        if "error" in quote:
            return f"error: Jupiter quote, {quote['error']}"

        out_sol = int(quote.get("outAmount", 0)) / 1e9
        log.info(f"Jupiter quote: {amount_usdc} USDC → ~{out_sol:.5f} SOL")

        # 2. Swap transaction
        swap_resp = requests.post(
            "https://api.jup.ag/swap/v1/swap",
            json={
                "quoteResponse":             quote,
                "userPublicKey":             user_pubkey,
                "wrapAndUnwrapSol":          True,
                "dynamicComputeUnitLimit":   True,
                "prioritizationFeeLamports": "auto",
            },
            timeout=15,
        )
        swap_resp.raise_for_status()
        swap_data = swap_resp.json()
        if "error" in swap_data:
            return f"error: Jupiter swap: {swap_data['error']}"

        # 3. Sign + broadcast (VersionedTransaction, Jupiter may use ALTs)
        # Jupiter returns a partially-signed tx (fee relayer already signed).
        # We must ADD our signature without clobbering the existing ones.
        from solders.transaction import VersionedTransaction as SoldersVTx  # type: ignore

        raw = base64.b64decode(swap_data["swapTransaction"])
        vtx = SoldersVTx.from_bytes(raw)

        # Sign the serialized message bytes and inject into the existing sigs list
        msg_bytes = bytes(vtx.message)
        our_sig = session_kp.sign_message(msg_bytes)

        # Find which signer index belongs to our pubkey and replace that slot
        account_keys = vtx.message.account_keys
        our_idx = next(
            (i for i, k in enumerate(account_keys) if str(k) == user_pubkey),
            None,
        )
        if our_idx is None:
            return "error: session pubkey not found in transaction account keys"

        existing_sigs = list(vtx.signatures)
        existing_sigs[our_idx] = our_sig
        vtx = SoldersVTx.populate(vtx.message, existing_sigs)

        sig = str(solana.send_raw_transaction(bytes(vtx)).value)
        log.info(f"✅ Jupiter swap confirmed: {out_sol:.5f} SOL received | sig: {sig}")
        return sig

    except Exception as e:
        return f"error: {e}"


def _send_usdc(session: SessionWallet, destination_pubkey: str, amount_usdc: float) -> str:
    """
    Send USDC from the session wallet to a destination address.
    Returns the transaction signature string.
    Raises on failure.
    """
    from solders.instruction import AccountMeta, Instruction
    from solders.message import Message
    from solders.transaction import Transaction as SoldersTransaction
    from solana.rpc.types import TxOpts

    session_kp = SoldersKeypair.from_bytes(session.secret_key_bytes)
    session_pubkey = session_kp.pubkey()
    dest_pubkey = Pubkey.from_string(destination_pubkey)

    # Resolve source ATA (session wallet's USDC account)
    src_accounts = solana.get_token_accounts_by_owner_json_parsed(
        session_pubkey,
        opts=TokenAccountOpts(mint=Pubkey.from_string(USDC_MINT)),
        commitment=Confirmed,
    ).value
    if not src_accounts:
        raise RuntimeError(f"Session wallet {str(session_pubkey)[:8]}... has no USDC token account")
    src_ata = src_accounts[0].pubkey

    # Resolve destination ATA (payment wallet's USDC account)
    dest_accounts = solana.get_token_accounts_by_owner_json_parsed(
        dest_pubkey,
        opts=TokenAccountOpts(mint=Pubkey.from_string(USDC_MINT)),
        commitment=Confirmed,
    ).value
    if not dest_accounts:
        raise RuntimeError(
            f"Payment wallet {destination_pubkey[:8]}... has no USDC token account. "
            "Fund it with USDC once to create the ATA."
        )
    dest_ata = dest_accounts[0].pubkey

    amount_raw = int(amount_usdc * 1_000_000)  # USDC = 6 decimals
    data = struct.pack("<BQ", 3, amount_raw)
    transfer_ix = Instruction(
        program_id=Pubkey.from_string("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"),
        accounts=[
            AccountMeta(src_ata, is_signer=False, is_writable=True),
            AccountMeta(dest_ata, is_signer=False, is_writable=True),
            AccountMeta(session_pubkey, is_signer=True, is_writable=False),
        ],
        data=data,
    )
    recent = solana.get_latest_blockhash(commitment=Confirmed)
    msg = Message.new_with_blockhash([transfer_ix], session_pubkey, recent.value.blockhash)
    tx = SoldersTransaction.new_unsigned(msg)
    tx.sign([session_kp], recent.value.blockhash)
    resp = solana.send_transaction(tx, opts=TxOpts(skip_preflight=True))
    sig = str(resp.value)
    log.info(f"✅ Sent {amount_usdc} USDC → {destination_pubkey[:8]}... | sig: {sig}")
    return sig


def _get_local_ip() -> str:
    """Best-effort: return this machine's LAN IP so the phone can reach us."""
    try:
        # Connect to an external address (doesn't actually send data) to determine
        # which local interface would be used, that interface's IP is our LAN IP.
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
    except Exception:
        return "127.0.0.1"


def _poll_for_funding(pubkey: str, expected_usdc: float) -> tuple[bool, str]:
    """
    Poll the session wallet until it receives USDC or timeout.
    Returns (funded: bool, tx_signature: str).
    """
    start = time.time()
    while time.time() - start < POLL_TIMEOUT:
        balance = _get_token_balance(pubkey, USDC_MINT)
        if balance >= expected_usdc * 0.95:  # Allow 5% slippage
            sig = _get_latest_tx_signature(pubkey)
            return True, sig

        # Also accept SOL as funding (for demo flexibility)
        try:
            sol_resp = solana.get_balance(Pubkey.from_string(pubkey), commitment=Confirmed)
            sol_balance = (sol_resp.value or 0) / 1e9
            if sol_balance > 0.01:
                sig = _get_latest_tx_signature(pubkey)
                log.info(f"Received {sol_balance:.4f} SOL (accepted as funding)")
                return True, sig
        except Exception:
            pass

        time.sleep(POLL_INTERVAL)

    return False, ""


def _get_latest_tx_signature(pubkey: str) -> str:
    """Get the most recent transaction signature for a pubkey."""
    try:
        sigs = solana.get_signatures_for_address(
            Pubkey.from_string(pubkey),
            limit=1,
            commitment=Confirmed,
        )
        if sigs.value:
            return str(sigs.value[0].signature)
    except Exception as e:
        log.warning(f"Failed to get tx signature: {e}")
    return "unknown"


def _get_token_balance(owner_pubkey: str, mint: str) -> float:
    """Get SPL token balance for a given owner and mint."""
    try:
        from solders.pubkey import Pubkey  # type: ignore

        resp = solana.get_token_accounts_by_owner_json_parsed(
            Pubkey.from_string(owner_pubkey),
            opts=TokenAccountOpts(mint=Pubkey.from_string(mint)),
            commitment=Confirmed,
        )

        if resp.value:
            for account in resp.value:
                parsed = account.account.data.parsed
                if parsed and "info" in parsed:
                    token_amount = parsed["info"].get("tokenAmount", {})
                    return float(token_amount.get("uiAmount", 0))
        return 0.0
    except Exception as e:
        log.warning(f"Token balance query failed: {e}")
        return 0.0


# ---------------------------------------------------------------------------
# Tool 6: request_with_payment  (x402 handler)
# ---------------------------------------------------------------------------
def request_with_payment(
    url: str,
    amount_usdc: float = 1.0,
    task_description: str = "",
    method: str = "GET",
    headers: dict | None = None,
    json_body: dict | None = None,
    return_funds_after: bool = True,
    source: str = "ask",
) -> dict:
    """
    Make an HTTP request to a paywalled endpoint that may return 402.

    If the server returns 402 with X-Payment-Required: tally, this function:
      1. Calls request_funding() to pause the agent and notify the user
      2. Waits for the card tap + on-chain confirmation
      3. Retries the original request with X-Tally-Session: <pubkey> header
      4. Optionally sweeps remaining funds back to the vault after the call

    Args:
        url:                 Target URL (e.g. "https://lll.mk/tally/signal")
        amount_usdc:         Amount to fund if 402 is hit (overridden by server
                             X-Payment-Amount header if present)
        task_description:    Human-readable reason shown in the Telegram notification
        method:              HTTP method ("GET" or "POST")
        headers:             Extra headers to include in both attempts
        json_body:           JSON body for POST requests
        return_funds_after:  If True, calls return_funds() after a successful
                             response. Set to False if you plan to make more
                             calls with the same session in this task.

    Returns:
        dict with:
            "status":   HTTP status code of the final response
            "ok":       True if response was 2xx
            "data":     Parsed JSON body (or raw text if not JSON)
            "session":  SessionWallet used (or None if no payment was needed)
            "funded":   True if a new funding session was opened
    """
    headers = dict(headers or {})
    task_description = task_description or f"Access {url}"

    # Standing-budget mode: pay straight from the pre-authorized vault budget,
    # no card tap and no session wallet. Falls through to ask-each-time otherwise.
    if source == "budget":
        return _request_with_budget(url, amount_usdc, method, headers, json_body)

    def _do_request(extra_headers: dict) -> requests.Response:
        merged = {**headers, **extra_headers}
        if method.upper() == "POST":
            return requests.post(url, headers=merged, json=json_body, timeout=30)
        return requests.get(url, headers=merged, timeout=30)

    # ── First attempt: no session header ────────────────────────────────────
    log.info(f"[x402] {method} {url}")
    resp = _do_request({})

    if resp.status_code != 402:
        # No payment needed: return immediately
        try:
            data = resp.json()
        except Exception:
            data = resp.text
        return {"status": resp.status_code, "ok": resp.ok, "data": data, "session": None, "funded": False}

    # ── 402 received: check if it's a Tally payment request ─────────────────
    payment_provider = resp.headers.get("X-Payment-Required", "").lower()
    if payment_provider != "tally":
        # Different payment provider: not our job
        log.warning(f"[x402] 402 from {url} but X-Payment-Required={payment_provider!r} (not tally)")
        return {"status": 402, "ok": False, "data": resp.text, "session": None, "funded": False}

    # Override amount from server header if provided
    server_amount = resp.headers.get("X-Payment-Amount", "")
    if server_amount:
        try:
            amount_usdc = float(server_amount)
        except ValueError:
            pass

    log.info(f"[x402] 402 hit, requesting ${amount_usdc} USDC funding for: {task_description}")

    # ── Fund the session via card tap ─────────────────────────────────────────
    session = request_funding(
        amount_usdc=amount_usdc,
        task_description=task_description,
    )

    # ── On-chain settlement: send USDC to payment wallet before retrying ────────
    # The payment wallet address comes from the server's 402 response header
    # (X-Payment-Wallet). The agent never hardcodes this, the server owns it.
    payment_tx_sig = None
    payment_wallet = resp.headers.get("X-Payment-Wallet", "").strip()
    if payment_wallet:
        try:
            payment_tx_sig = _send_usdc(session, payment_wallet, amount_usdc)
            log.info(f"[x402] Payment sent on-chain: {amount_usdc} USDC → {payment_wallet[:8]}... | tx: {payment_tx_sig}")
        except Exception as e:
            log.error(f"[x402] On-chain payment failed: {e}")
            return {"status": 402, "ok": False, "data": str(e), "session": session, "funded": True}

    # ── Retry with session header (+ tx proof if payment was made) ─────────────
    retry_headers: dict = {"X-Tally-Session": session.pubkey}
    if payment_tx_sig:
        retry_headers["X-Tally-Tx"] = payment_tx_sig
        # Wait for the payment tx to propagate to the server's RPC node.
        # The server polls for ~8s after it receives our request, 10s client-side
        # delay ensures the tx is already visible when it starts looking.
        log.info(f"[x402] Waiting 10s for tx propagation before retry...")
        time.sleep(10)
    log.info(f"[x402] Retrying {url}...")
    retry_resp = _do_request(retry_headers)

    try:
        data = retry_resp.json()
    except Exception:
        data = retry_resp.text

    # ── Optionally sweep remaining funds back ─────────────────────────────────
    if return_funds_after and retry_resp.ok:
        try:
            sig = return_funds(session)
            log.info(f"[x402] Funds returned to vault | sweep sig: {sig}")
        except Exception as e:
            log.warning(f"[x402] return_funds failed (non-fatal): {e}")

    return {
        "status":  retry_resp.status_code,
        "ok":      retry_resp.ok,
        "data":    data,
        "session": session,
        "funded":  True,
    }


# ---------------------------------------------------------------------------
# Standing budgets: pay direct from the vault (subscriptions program)
# ---------------------------------------------------------------------------
# A standing budget is an on-chain FixedDelegation the user created for this
# agent's session pubkey with a single card tap. The agent pays payees straight
# from the vault within the cap via transferFixed, signed by its session key.
# Funds never sit in a hot wallet, and the expiry is enforced on-chain: once the
# window closes the next payment is rejected and the unspent cap stays put.
#
# Wire format mirrors @solana/subscriptions (program De1egAF...). That program
# uses single-byte instruction discriminators (transferFixed = 4), not Anchor
# 8-byte hashes. The FixedDelegation account is 187 bytes; offsets below.
SUBSCRIPTIONS_PROGRAM    = Pubkey.from_string("De1egAFMkMWZSN5rYXRj9CAdheBamobVNubTsi9avR44")
SUBSCRIPTIONS_EVENT_AUTH = Pubkey.from_string("3Hnj4BYoDgtpBuqXfiy7Y8cNa3jXaNd4oqgSXBzkMcH7")
TOKEN_PROGRAM_ID         = Pubkey.from_string("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA")
ATA_PROGRAM_ID           = Pubkey.from_string("ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL")
SYSTEM_PROGRAM_ID        = Pubkey.from_string("11111111111111111111111111111111")

_FD_SIZE          = 187   # FixedDelegation account size
_FD_OFF_DELEGATOR = 3     # header: disc(1) version(1) bump(1), then delegator(32)
_FD_OFF_DELEGATEE = 35    # delegator(32), then delegatee(32)
_FD_OFF_AMOUNT    = 171   # ...payer(32) initId(8) subAuthority(32) mint(32), then amount u64
_FD_OFF_EXPIRY    = 179   # then expiryTs i64


def _session_keypair() -> "SoldersKeypair":
    sk = os.getenv("TALLY_SESSION_SK", "").strip()
    if not sk:
        raise RuntimeError("TALLY_SESSION_SK is not set in .env")
    raw = base64.urlsafe_b64decode(sk + "==")
    return SoldersKeypair.from_seed(raw[:32])


def _ata(owner: Pubkey, mint: Pubkey) -> Pubkey:
    ata, _ = Pubkey.find_program_address(
        [bytes(owner), bytes(TOKEN_PROGRAM_ID), bytes(mint)], ATA_PROGRAM_ID
    )
    return ata


def _subscription_authority_pda(user: Pubkey, mint: Pubkey) -> Pubkey:
    pda, _ = Pubkey.find_program_address(
        [b"SubscriptionAuthority", bytes(user), bytes(mint)], SUBSCRIPTIONS_PROGRAM
    )
    return pda


def _decode_account_data(raw) -> bytes:
    if isinstance(raw, bytes):
        return raw
    if isinstance(raw, (list, tuple)):
        return base64.b64decode(raw[0])
    if isinstance(raw, str):
        return base64.b64decode(raw)
    return bytes(raw)


def _find_budget_delegations(vault_pubkey: str, delegatee: Pubkey) -> list:
    """Return [(delegation_pda, remaining_base_units, expiry_ts)] for this agent.

    Discovers the agent's FixedDelegation accounts via getProgramAccounts,
    filtered by account size and the delegatee pubkey at byte offset 35, then
    keeps only those whose delegator matches the vault.
    """
    from solana.rpc.types import MemcmpOpts
    resp = solana.get_program_accounts(
        SUBSCRIPTIONS_PROGRAM,
        commitment=Confirmed,
        encoding="base64",
        filters=[_FD_SIZE, MemcmpOpts(offset=_FD_OFF_DELEGATEE, bytes=str(delegatee))],
    )
    out = []
    for acc in resp.value:
        data = _decode_account_data(acc.account.data)
        if len(data) < _FD_SIZE:
            continue
        delegator = str(Pubkey.from_bytes(data[_FD_OFF_DELEGATOR:_FD_OFF_DELEGATOR + 32]))
        if vault_pubkey and delegator != vault_pubkey:
            continue
        amount = int.from_bytes(data[_FD_OFF_AMOUNT:_FD_OFF_AMOUNT + 8], "little")
        expiry = int.from_bytes(data[_FD_OFF_EXPIRY:_FD_OFF_EXPIRY + 8], "little", signed=True)
        out.append((acc.pubkey, amount, expiry))
    return out


def budget_status(vault_pubkey: str = "") -> dict:
    """
    Inspect the agent's active standing budget (on-chain FixedDelegation).

    Returns:
        remaining_usdc: float    cap still spendable
        expiry_ts:      int      unix seconds the budget expires
        delegation_pda: str|None the on-chain delegation address (None if none)
        active:         bool     True if remaining > 0 and not expired
    """
    vault = (vault_pubkey or VAULT_PUBKEY).strip()
    try:
        delegatee = _session_keypair().pubkey()
        rows = _find_budget_delegations(vault, delegatee)
    except Exception as e:
        log.warning(f"[budget] status lookup failed: {e}")
        return {"remaining_usdc": 0.0, "expiry_ts": 0, "delegation_pda": None, "active": False}
    if not rows:
        return {"remaining_usdc": 0.0, "expiry_ts": 0, "delegation_pda": None, "active": False}
    now = int(time.time())
    # Prefer an active budget (cap left, not expired); else the latest expiry.
    rows.sort(key=lambda r: (1 if (r[1] > 0 and r[2] > now) else 0, r[2]), reverse=True)
    pda, amount, expiry = rows[0]
    return {
        "remaining_usdc": amount / 1_000_000,
        "expiry_ts": expiry,
        "delegation_pda": str(pda),
        "active": amount > 0 and expiry > now,
    }


def _create_ata_idempotent_ix(payer: Pubkey, owner: Pubkey, mint: Pubkey):
    from solders.instruction import AccountMeta, Instruction
    return Instruction(
        program_id=ATA_PROGRAM_ID,
        accounts=[
            AccountMeta(payer, is_signer=True, is_writable=True),
            AccountMeta(_ata(owner, mint), is_signer=False, is_writable=True),
            AccountMeta(owner, is_signer=False, is_writable=False),
            AccountMeta(mint, is_signer=False, is_writable=False),
            AccountMeta(SYSTEM_PROGRAM_ID, is_signer=False, is_writable=False),
            AccountMeta(TOKEN_PROGRAM_ID, is_signer=False, is_writable=False),
        ],
        data=bytes([1]),  # CreateIdempotent
    )


def _transfer_fixed_ix(delegation_pda, sa_pda, vault_ata, dest_ata, mint, delegatee, amount_raw, delegator):
    from solders.instruction import AccountMeta, Instruction
    # data = u8 discriminator(4) | u64 amount | delegator(32) | mint(32)
    data = bytes([4]) + int(amount_raw).to_bytes(8, "little") + bytes(delegator) + bytes(mint)
    return Instruction(
        program_id=SUBSCRIPTIONS_PROGRAM,
        accounts=[
            AccountMeta(delegation_pda, is_signer=False, is_writable=True),
            AccountMeta(sa_pda, is_signer=False, is_writable=False),
            AccountMeta(vault_ata, is_signer=False, is_writable=True),
            AccountMeta(dest_ata, is_signer=False, is_writable=True),
            AccountMeta(mint, is_signer=False, is_writable=False),
            AccountMeta(TOKEN_PROGRAM_ID, is_signer=False, is_writable=False),
            AccountMeta(delegatee, is_signer=True, is_writable=False),
            AccountMeta(SUBSCRIPTIONS_EVENT_AUTH, is_signer=False, is_writable=False),
            AccountMeta(SUBSCRIPTIONS_PROGRAM, is_signer=False, is_writable=False),
        ],
        data=data,
    )


def pay_from_budget(destination_pubkey: str, amount_usdc: float, vault_pubkey: str = "") -> str:
    """
    Pay `amount_usdc` straight from the user's vault to `destination_pubkey`,
    drawing on the agent's standing budget. Signed by the session key. Creates
    the destination's USDC ATA idempotently if missing. Returns the tx signature.

    The vault key never participates; the program checks the cap and expiry and
    moves USDC from the vault ATA to the payee. Raises if there is no budget, it
    is expired/exhausted, or the cap is below the requested amount.
    """
    from solders.message import Message
    from solders.transaction import Transaction as SoldersTransaction
    from solana.rpc.types import TxOpts

    vault = (vault_pubkey or VAULT_PUBKEY).strip()
    if not vault:
        raise ValueError("No vault address. Set TALLY_VAULT_PUBKEY in .env or pass vault_pubkey.")
    mint = Pubkey.from_string(USDC_MINT)
    session_kp = _session_keypair()
    delegatee = session_kp.pubkey()
    dest = Pubkey.from_string(destination_pubkey)
    amount_raw = int(round(amount_usdc * 1_000_000))  # USDC = 6 decimals
    if amount_raw <= 0:
        raise ValueError("amount_usdc must be positive")

    rows = _find_budget_delegations(vault, delegatee)
    if not rows:
        raise RuntimeError(
            "No standing budget for this agent. Ask the user to authorize one in the "
            "Tally app (Agents tab, set a budget and tap their card)."
        )
    now = int(time.time())
    spendable = [r for r in rows if r[1] >= amount_raw and r[2] > now]
    if not spendable:
        best = max(rows, key=lambda r: r[2])
        if best[2] <= now:
            raise RuntimeError("Standing budget has expired. Ask the user to re-authorize.")
        raise RuntimeError(
            f"Budget too low: {best[1] / 1_000_000:.4f} USDC left, need {amount_usdc:.4f}. "
            "Ask the user to raise the cap or start a new budget."
        )
    delegation_pda = spendable[0][0]

    vault_pk = Pubkey.from_string(vault)
    sa_pda = _subscription_authority_pda(vault_pk, mint)
    vault_ata = _ata(vault_pk, mint)
    dest_ata = _ata(dest, mint)

    ixs = [
        _create_ata_idempotent_ix(delegatee, dest, mint),
        _transfer_fixed_ix(delegation_pda, sa_pda, vault_ata, dest_ata, mint, delegatee, amount_raw, vault_pk),
    ]
    recent = solana.get_latest_blockhash(commitment=Confirmed)
    msg = Message.new_with_blockhash(ixs, delegatee, recent.value.blockhash)
    tx = SoldersTransaction.new_unsigned(msg)
    tx.sign([session_kp], recent.value.blockhash)

    skip = "helius" in RPC_URL.lower()  # Helius devnet rejects on stale blockhash preflight
    try:
        resp = solana.send_transaction(tx, opts=TxOpts(skip_preflight=skip, preflight_commitment=Confirmed))
    except Exception as e:
        raise RuntimeError(f"transferFixed rejected (cap/expiry enforced on-chain): {e}")
    sig = resp.value
    solana.confirm_transaction(sig, commitment=Confirmed)
    st = solana.get_signature_statuses([sig]).value[0]
    if st is not None and st.err is not None:
        raise RuntimeError(f"Payment failed on-chain (cap/expiry enforced): {st.err}")
    log.info(f"💸 Paid {amount_usdc} USDC from budget → {destination_pubkey[:8]}... | sig: {sig}")
    return str(sig)


def _request_with_budget(url, amount_usdc, method, headers, json_body) -> dict:
    """x402 in standing-budget mode: pay the endpoint straight from the vault,
    no card tap, no session wallet, no sweep."""
    headers = dict(headers or {})

    def _do(extra):
        merged = {**headers, **extra}
        if method.upper() == "POST":
            return requests.post(url, headers=merged, json=json_body, timeout=30)
        return requests.get(url, headers=merged, timeout=30)

    log.info(f"[x402:budget] {method} {url}")
    resp = _do({})
    if resp.status_code != 402:
        try:
            data = resp.json()
        except Exception:
            data = resp.text
        return {"status": resp.status_code, "ok": resp.ok, "data": data, "session": None, "funded": False}

    if resp.headers.get("X-Payment-Required", "").lower() != "tally":
        return {"status": 402, "ok": False, "data": resp.text, "session": None, "funded": False}

    srv_amt = resp.headers.get("X-Payment-Amount", "")
    if srv_amt:
        try:
            amount_usdc = float(srv_amt)
        except ValueError:
            pass
    wallet = resp.headers.get("X-Payment-Wallet", "").strip()
    if not wallet:
        return {"status": 402, "ok": False,
                "data": "Budget mode needs X-Payment-Wallet from the server to settle on-chain",
                "session": None, "funded": False}

    try:
        sig = pay_from_budget(wallet, amount_usdc)
    except Exception as e:
        log.error(f"[x402:budget] payment failed: {e}")
        return {"status": 402, "ok": False, "data": str(e), "session": None, "funded": False}

    delegatee = str(_session_keypair().pubkey())
    log.info("[x402:budget] paid from vault, waiting 10s for tx propagation before retry...")
    time.sleep(10)
    retry = _do({"X-Tally-Session": delegatee, "X-Tally-Tx": sig})
    try:
        data = retry.json()
    except Exception:
        data = retry.text
    return {"status": retry.status_code, "ok": retry.ok, "data": data,
            "session": None, "funded": True, "paid_from_budget": True, "tx": sig}


# ---------------------------------------------------------------------------
# Agent-proposed budget: the agent asks the user to authorize a standing budget
# ---------------------------------------------------------------------------
def _parse_ttl(ttl) -> int:
    """Accept an int (seconds) or a short string like '7d' / '24h' / '30m'."""
    if isinstance(ttl, (int, float)):
        return int(ttl)
    s = str(ttl).strip().lower()
    units = {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}
    if s and s[-1] in units:
        return int(float(s[:-1]) * units[s[-1]])
    return int(float(s))


def request_budget(amount_usdc, ttl_seconds, reason, label=None) -> dict:
    """
    Research-and-propose a standing budget. Sizes nothing on its own (the agent
    decides amount_usdc, optionally via EVEngine); sends the user a signed
    Telegram deep link that opens the app's Authorize Budget screen pre-filled.

    Fire-and-forget: returns immediately. Approval is human-paced, so call
    budget_status() or wait_for_budget() when you actually want to spend.

    ttl_seconds accepts an int (seconds) or a short string like "7d" / "24h".
    Returns {agent, amount_usdc, ttl_seconds, reason, deep_link, sent}.
    """
    agent = str(_session_keypair().pubkey())
    ttl = _parse_ttl(ttl_seconds)
    deep_link = send_authorize_budget(agent, amount_usdc, ttl, reason, label)
    return {
        "agent": agent,
        "amount_usdc": amount_usdc,
        "ttl_seconds": ttl,
        "reason": reason,
        "deep_link": deep_link,
        "sent": True,
    }


def wait_for_budget(
    timeout_seconds: int = 600,
    poll_interval: int = 5,
    min_usdc: Optional[float] = None,
) -> Optional[dict]:
    """
    Block until an active budget appears for this agent (optionally with at least
    `min_usdc` remaining), or return None on timeout. Pairs with request_budget.
    """
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        b = budget_status()
        if b["active"] and (min_usdc is None or b["remaining_usdc"] >= min_usdc):
            return b
        time.sleep(poll_interval)
    return None


# ---------------------------------------------------------------------------
# Skill Metadata (for OpenClaw discovery)
# ---------------------------------------------------------------------------
SKILL_MANIFEST = {
    "name": "tally",
    "version": "0.1.0",
    "description": "Physical API key for agent commerce. Tap a bank card to authorize agent funding.",
    "tools": [
        {
            "name": "request_funding",
            "description": "Request USDC funding for agent operations. Sends a Telegram notification and waits for physical card-tap authorization.",
            "parameters": {
                "amount_usdc": {"type": "float", "required": True, "description": "Amount in USDC"},
                "task_description": {"type": "string", "required": True, "description": "What the agent needs the funds for"},
                "estimated_ops": {"type": "int", "required": False, "default": 1},
                "avg_cost_per_op": {"type": "float", "required": False, "default": 0.0},
                "risk_score": {"type": "float", "required": False, "default": 0.5},
            },
        },
        {
            "name": "check_session_balance",
            "description": "Check the on-chain SOL and USDC balance of a session wallet.",
            "parameters": {
                "session_pubkey": {"type": "string", "required": True},
            },
        },
        {
            "name": "budget_status",
            "description": "Read the agent's standing budget (on-chain FixedDelegation): remaining cap, expiry, and whether it is active. No card tap.",
            "parameters": {
                "vault_pubkey": {"type": "string", "required": False, "description": "Defaults to TALLY_VAULT_PUBKEY"},
            },
        },
        {
            "name": "pay_from_budget",
            "description": "Pay USDC straight from the user's vault to a payee, within the pre-authorized standing budget. Signed by the session key; the vault key never participates. No card tap.",
            "parameters": {
                "destination_pubkey": {"type": "string", "required": True},
                "amount_usdc": {"type": "float", "required": True},
                "vault_pubkey": {"type": "string", "required": False, "description": "Defaults to TALLY_VAULT_PUBKEY"},
            },
        },
        {
            "name": "request_budget",
            "description": "Propose a standing budget (amount, duration, reason) to the user. Sends a Telegram deep link that opens the app's Authorize Budget screen pre-filled; the user approves with a card tap. Fire-and-forget; poll budget_status() or wait_for_budget() afterwards.",
            "parameters": {
                "amount_usdc": {"type": "float", "required": True},
                "ttl_seconds": {"type": "int|string", "required": True, "description": "Seconds, or a short string like '7d' / '24h'"},
                "reason": {"type": "string", "required": True},
                "label": {"type": "string", "required": False, "description": "Agent display name"},
            },
        },
        {
            "name": "wait_for_budget",
            "description": "Block until an active budget appears for this agent (optionally with at least min_usdc remaining), or return None on timeout.",
            "parameters": {
                "timeout_seconds": {"type": "int", "required": False, "default": 600},
                "poll_interval": {"type": "int", "required": False, "default": 5},
                "min_usdc": {"type": "float", "required": False},
            },
        },
        {
            "name": "return_funds",
            "description": "Sweep remaining session wallet funds back to the master vault.",
            "parameters": {
                "session": {"type": "SessionWallet", "required": True},
                "master_vault_pubkey": {"type": "string", "required": True},
            },
        },
        {
            "name": "monitor_session",
            "description": "Monitor session wallet balance and send a proactive Telegram heartbeat if it's running low.",
            "parameters": {
                "session_pubkey": {"type": "string", "required": True},
                "threshold_usdc": {"type": "float", "required": False, "default": 2.0},
            },
        },
        {
            "name": "ensure_gas",
            "description": (
                "Ensure the session wallet has enough SOL for transaction fees. "
                "Call before any on-chain operation. On mainnet: auto-swaps ~$1 of session USDC→SOL via Jupiter "
                "(no user tap needed: Jupiter's relayer covers the swap fee). "
                "On devnet or if Jupiter fails: sends a Telegram notification asking the user to "
                "authorize a small SOL top-up via card tap. Returns immediately if gas is sufficient."
            ),
            "parameters": {
                "session": {"type": "SessionWallet", "required": True},
            },
        },
    ],
}


if __name__ == "__main__":
    # Quick smoke test
    print(json.dumps(SKILL_MANIFEST, indent=2))
    ev = EVEngine.calculate_request(estimated_ops=500, avg_cost_per_op=0.03, risk_score=0.3)
    print(f"\nEV Engine test: {json.dumps(ev, indent=2)}")
