"""
Tally x402 Demo Agent
=====================
Demonstrates the full x402 payment flow end-to-end:

  1. Agent calls the paywalled signal endpoint → gets 402
  2. request_with_payment() catches the 402, calls request_funding()
  3. Telegram notification sent → user taps card in Tally app
  4. Session wallet funded on-chain
  5. Agent retries the request with X-Tally-Session header → gets signal
  6. Agent uses the signal data
  7. return_funds() sweeps remaining USDC back to master vault

Prerequisites:
  - .env configured with TALLY_SESSION_SK, TALLY_TG_TOKEN, TALLY_TG_CHAT_ID,
    TALLY_VAULT_PUBKEY, and optionally TALLY_RPC_URL
  - Tally app open on your phone, vault unlocked
  - Signal server deployed (or running locally on SIGNAL_URL)

Usage:
  python run_x402_demo.py
  python run_x402_demo.py --url https://tally-signal.vercel.app/api/signal
  python run_x402_demo.py --url http://localhost:5402/signal --amount 0.5
"""

import argparse
import json
import logging
import sys
from warm_vault_auth import request_with_payment

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [demo] %(message)s",
    stream=sys.stdout,
)
log = logging.getLogger("x402-demo")

SIGNAL_URL_DEFAULT = "https://tally-signal.vercel.app/api/signal"


def run_demo(signal_url: str, amount_usdc: float) -> None:
    log.info("=" * 60)
    log.info("Tally x402 Demo — Physical API Key for Agent Commerce")
    log.info("=" * 60)
    log.info(f"Target: {signal_url}")
    log.info(f"Budget: ${amount_usdc} USDC")
    log.info("")

    # ── Step 1: Hit the paywalled endpoint via request_with_payment ──────────
    # This will:
    #   • Make an initial GET → receive 402
    #   • Detect X-Payment-Required: tally header
    #   • Call request_funding() → send Telegram notification
    #   • Poll until card tap + on-chain confirmation
    #   • Retry with X-Tally-Session header
    #   • Sweep funds back to vault (return_funds_after=True)
    log.info("[Step 1] Calling request_with_payment()...")
    log.info("         (expect 402 → Telegram notification → card tap → retry)")

    result = request_with_payment(
        url=signal_url,
        amount_usdc=amount_usdc,
        task_description="Fetch premium SOL/USDC market signal",
        return_funds_after=True,
    )

    # ── Step 2: Handle the result ─────────────────────────────────────────────
    log.info("")
    log.info(f"[Step 2] Final status: {result['status']} | funded: {result['funded']}")

    if not result["ok"]:
        log.error(f"Request failed: {result['data']}")
        sys.exit(1)

    data = result["data"]
    signal = data.get("signal", {})

    log.info("")
    log.info("=" * 60)
    log.info("SIGNAL RECEIVED")
    log.info("=" * 60)
    log.info(f"  Asset:      {signal.get('asset', 'N/A')}")
    log.info(f"  Direction:  {signal.get('signal', 'N/A')}")
    log.info(f"  Confidence: {signal.get('confidence', 'N/A')}")
    log.info(f"  Entry:      {signal.get('entry', 'N/A')}")
    log.info(f"  Target:     {signal.get('target', 'N/A')}")
    log.info(f"  Stop Loss:  {signal.get('stop_loss', 'N/A')}")
    log.info(f"  Timeframe:  {signal.get('timeframe', 'N/A')}")
    log.info(f"  R:R Ratio:  {signal.get('basis', {}).get('rr', 'N/A')}")
    log.info("")

    if result["funded"]:
        session = result["session"]
        log.info(f"  Session:    {session.pubkey[:16]}...")
        log.info(f"  Funded:     ${session.funded_amount} USDC")
        log.info("")
        log.info("[Done] Funds swept back to vault. Session closed.")
    else:
        log.info("[Done] No payment was required (session already active or free access).")

    log.info("")
    log.info("Full response:")
    # Exclude secret key bytes from print
    safe_data = dict(result)
    if safe_data.get("session"):
        safe_data["session"] = {
            "pubkey": result["session"].pubkey,
            "funded_amount": result["session"].funded_amount,
            "currency": result["session"].currency,
            "task_description": result["session"].task_description,
        }
    print(json.dumps(safe_data.get("data", {}), indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Tally x402 demo agent")
    parser.add_argument(
        "--url",
        default=SIGNAL_URL_DEFAULT,
        help=f"Signal endpoint URL (default: {SIGNAL_URL_DEFAULT})",
    )
    parser.add_argument(
        "--amount",
        type=float,
        default=1.0,
        help="USDC amount to fund (default: 1.0)",
    )
    args = parser.parse_args()
    run_demo(args.url, args.amount)
