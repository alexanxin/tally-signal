# Testing the Tally Integration With Your Agent

A practical, step-by-step walkthrough to confirm the agent toolset works
end-to-end after the 2026-06-12 fixes. Budget ~15 minutes. Use **small
amounts** — everything here moves real value on whichever network you point at.

Pick your network up front. **Devnet** is free and safe for a first run;
**mainnet** exercises the real fee rails. Set `TALLY_RPC_URL` accordingly (the
skill auto-selects the matching USDC mint).

---

## 0. Prerequisites

- Tally 1.7.0 installed, vault created, app open with the vault unlocked.
- The app set to the **same network** as your `TALLY_RPC_URL`
  (Home → Settings cog → Network). Devnet override beats build config, so
  check it.
- Python 3.10+ with `solders`, `solana`, `requests` installed
  (`pip install solders solana requests`).
- A funded vault: a little SOL for gas, and some USDC if testing payments.

---

## 1. One-time credential setup (`.env`)

Copy `.env.example` to `.env`, then fill these in:

1. **`TALLY_SESSION_SK`** — in the app: **Wallets → New Wallet → Agent**, tap
   your card, and on the success screen copy the base58 **private key** (shown
   once). Paste it here. This is the agent's stable identity key.
2. **`TALLY_VAULT_PUBKEY`** — your master vault address (Home, tap the address
   pill to copy).
3. **`TALLY_DEEP_LINK_SECRET`** — in the app: **Home → Settings cog →
   Deep Link Secret → Generate**, copy it here. This is what makes the
   Telegram links trusted (the app warns on unsigned links).
4. **`TALLY_TG_TOKEN` / `TALLY_TG_CHAT_ID`** — optional. With them you get real
   Telegram buttons; **without them the skill prints the deep link to the
   console** (fine for a first test — you just open the link on your phone
   manually).
5. **`TALLY_RPC_URL`** — your devnet or mainnet RPC (Helius recommended).

Sanity check the wiring (no funds move):

```bash
cd tally_integration
python warm_vault_auth.py          # prints the SKILL_MANIFEST (v0.2.0) + EV demo
```

You should see `request_with_payment` listed first in the tools, and version
`0.2.0`.

---

## 2. Test A — the x402 round trip (the headline flow)

This hits the live paywalled signal endpoint, pays for it, and sweeps the
change back. It exercises `request_with_payment` → `request_funding` →
`_send_usdc` (now confirmed + idempotent ATA) → retry → `return_funds`.

```bash
python run_x402_demo.py --amount 0.5
# devnet: point at your own endpoint, or use --url for the mainnet signal
```

What should happen, in order:

1. The agent hits the endpoint, gets **402**, and logs "requesting funding".
2. A **Telegram message** (or console deep link) arrives. Open it → the Tally
   **Authorize** screen → tap your card.
3. The agent's poll detects the funding **delta** (not just any balance) and
   continues — log line `Polling for funding (... baseline: X USDC)`.
4. It pays the endpoint, **waits ~2s** (not 10), retries, and prints the
   **SIGNAL RECEIVED** block.
5. `return_funds` sweeps the remainder back; you get a **"Funds Returned to
   Vault"** Telegram/console confirmation.

✅ Pass: you see the signal and the sweep confirmation, and the agent wallet
ends near-zero on-chain.

---

## 3. Test B — the funding-delta fix (the important correctness check)

This proves a card tap is genuinely required and stale balance can't fake it.

1. Run Test A once and **let it fund** (tap the card). Note the agent wallet
   now holds leftover USDC if any.
2. Immediately run it **again**:

```bash
python run_x402_demo.py --amount 0.5
```

✅ Pass: the second run does **not** auto-proceed on the leftover balance — it
sends a **new** Telegram/console request and waits for a fresh tap. Before the
fix it would have sailed through without a tap. If you don't tap within
`TALLY_POLL_TIMEOUT`, it times out cleanly.

---

## 4. Test C — standing budget (no tap per call)

This is the `source="budget"` path — the agent pays straight from a
pre-authorized on-chain budget, no tap per request.

1. In the app: **Agents** (or **Connections**) → set a budget for this agent's
   pubkey (it's your `TALLY_SESSION_SK`'s public key) → tap card to authorize.
2. From Python:

```python
from warm_vault_auth import budget_status, request_with_payment

print(budget_status())                      # remaining cap, expiry, active=True

r = request_with_payment(
    url="https://tally.lll.mk/api/signal",   # or your endpoint
    source="budget",                          # pay from the standing budget
    amount_usdc=0.5,
)
print(r["status"], r.get("paid_from_budget"), r.get("tx"))
```

✅ Pass: `budget_status()` shows `active: True`; the call pays from the vault
with **no card tap**, returns the signal, and the budget's remaining cap drops
by the amount.

---

## 5. Test D — full multi-token sweep

Confirms `return_funds` now retrieves **every** token, not just USDC/SOL.

1. Fund an agent session (Test A) and, before it sweeps, send a tiny bit of
   another SPL token to the agent pubkey (e.g. stake a hair of its SOL into
   JupSOL via the app's Convert, then send the JupSOL to the agent — or just
   airdrop any devnet SPL token to it).
2. Call `return_funds(session)` (or let the demo's `return_funds_after` run).

✅ Pass: the log shows `Swept ... of <mint>… back + closed ATA` for the
non-USDC token, and the agent wallet ends with no token accounts left.

---

## What to watch for (the fixes in action)

| Log line / behavior | Confirms |
|---|---|
| `Polling for funding (... baseline: N USDC)` | A1 — delta detection |
| second run re-prompts for a tap | A1 — no stale-balance bypass |
| `Payment confirmed; brief propagation buffer` (~2s) | A3 + C13 |
| paying a brand-new payee succeeds | A4 — idempotent ATA |
| `Swept ... of <mint>… back + closed ATA` | A5 — all-token sweep |
| Telegram says "the app funds this session wallet" (no "copy the key after") | B9/B10 |

## Troubleshooting

- **"TALLY_SESSION_SK is not set"** → step 1.1.
- **App shows "unsigned link" warning** → `TALLY_DEEP_LINK_SECRET` missing or
  doesn't match the app's (Settings → Deep Link Secret).
- **Funding times out** → app on the wrong network, or vault locked, or you
  didn't open/tap the deep link in time (`TALLY_POLL_TIMEOUT`, default 120s).
- **"No standing budget for this agent"** (Test C) → authorize one in the
  Agents tab first; the budget's delegatee must be this agent's pubkey.
- **Jupiter/`ensure_gas` errors on devnet** → expected; Jupiter has no devnet
  liquidity, so gas self-funding falls back to a Telegram top-up request.
