"""
Full flow: request $3, send $2 to FiPGw32Z.
"""
import sys, os, base64, struct

from warm_vault_auth import request_funding, solana, USDC_MINT_DEVNET, TokenAccountOpts
from solders.pubkey import Pubkey
from solders.keypair import Keypair as SoldersKeypair
from solders.instruction import AccountMeta, Instruction
from solders.message import Message
from solders.transaction import Transaction
from solana.rpc.commitment import Confirmed
from solana.rpc.types import TxOpts

DEST = "FiPGw32ZAQwfLovLtQQvRBKeFwrNPFNmBTcBpozAyUBK"
SEND_AMOUNT = 2.0
FUND_AMOUNT = 3.0

raw_sk = base64.urlsafe_b64decode(os.getenv("TALLY_SESSION_SK") + "==")
kp = SoldersKeypair.from_seed(raw_sk[:32])

print("=== Step 1: Request funding ===")
session = request_funding(amount_usdc=FUND_AMOUNT, task_description=f"Send ${SEND_AMOUNT} to FiPGw32Z")
print(f"✅ Funded: {session.funded_amount} USDC — {session.pubkey}")

print(f"\n=== Step 2: Send ${SEND_AMOUNT} USDC ===")

src_accounts = solana.get_token_accounts_by_owner_json_parsed(
    kp.pubkey(),
    opts=TokenAccountOpts(mint=Pubkey.from_string(USDC_MINT_DEVNET)),
    commitment=Confirmed,
).value
if not src_accounts:
    print("❌ No source USDC ATA"); sys.exit(1)
src = src_accounts[0].pubkey

dest_accounts = solana.get_token_accounts_by_owner_json_parsed(
    Pubkey.from_string(DEST),
    opts=TokenAccountOpts(mint=Pubkey.from_string(USDC_MINT_DEVNET)),
    commitment=Confirmed,
).value
if not dest_accounts:
    print("❌ No dest USDC ATA"); sys.exit(1)
dest = dest_accounts[0].pubkey

print(f"Source: {src}")
print(f"Dest:   {dest}")

data = struct.pack("<BQ", 3, int(SEND_AMOUNT * 1e6))
ix = Instruction(
    program_id=Pubkey.from_string("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"),
    accounts=[
        AccountMeta(src, is_signer=False, is_writable=True),
        AccountMeta(dest, is_signer=False, is_writable=True),
        AccountMeta(kp.pubkey(), is_signer=True, is_writable=False),
    ],
    data=data,
)

recent = solana.get_latest_blockhash(commitment=Confirmed)
msg = Message.new_with_blockhash([ix], kp.pubkey(), recent.value.blockhash)
tx = Transaction.new_unsigned(msg)
tx.sign([kp], recent.value.blockhash)

result = solana.send_transaction(tx, opts=TxOpts(skip_preflight=True))
print(f"\n✅ Sent ${SEND_AMOUNT} USDC")
print(f"   Tx: {result.value}")
