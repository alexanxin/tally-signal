"""
Full end-to-end test:
1. Request $2 funding via Telegram card tap
2. Send $1 USDC to FiPGw32ZAQwfLovLtQQvRBKeFwrNPFNmBTcBpozAyUBK
"""
import sys, os, base64, struct

from warm_vault_auth import request_funding, solana, USDC_MINT_DEVNET, TokenAccountOpts
from solders.pubkey import Pubkey
from solders.keypair import Keypair as SoldersKeypair
from solders.instruction import AccountMeta, Instruction
from solders.message import Message
from solders.transaction import Transaction
from solana.rpc.commitment import Confirmed

DEST = "FiPGw32ZAQwfLovLtQQvRBKeFwrNPFNmBTcBpozAyUBK"
AMOUNT = 1.0
USDC_PROGRAM = Pubkey.from_string("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA")

# Load session keypair from env
raw_sk = base64.urlsafe_b64decode(os.getenv("TALLY_SESSION_SK") + "==")
kp = SoldersKeypair.from_seed(raw_sk[:32])

print("=== Step 1: Request $2 funding ===")
session = request_funding(amount_usdc=2.0, task_description="Test spend — send $1 to FiPGw32Z")
print(f"✅ Funded: {session.funded_amount} USDC — {session.pubkey}")

print(f"\n=== Step 2: Send ${AMOUNT} USDC to {DEST[:16]}... ===")

# Find source USDC token account
src_accounts = solana.get_token_accounts_by_owner_json_parsed(
    kp.pubkey(),
    opts=TokenAccountOpts(mint=Pubkey.from_string(USDC_MINT_DEVNET)),
    commitment=Confirmed,
).value

if not src_accounts:
    print("❌ No USDC token account found")
    sys.exit(1)

src_token_account = src_accounts[0].pubkey

# Find destination USDC token account
dest_accounts = solana.get_token_accounts_by_owner_json_parsed(
    Pubkey.from_string(DEST),
    opts=TokenAccountOpts(mint=Pubkey.from_string(USDC_MINT_DEVNET)),
    commitment=Confirmed,
).value

if not dest_accounts:
    print("❌ Destination has no USDC token account")
    sys.exit(1)

dest_token_account = dest_accounts[0].pubkey
print(f"Source ATA: {src_token_account}")
print(f"Dest ATA:   {dest_token_account}")

# Build SPL Transfer instruction
# Instruction 3 = Transfer in SPL Token program, amount as 8-byte little-endian
data = struct.pack("<BQ", 3, int(AMOUNT * 1e6))

transfer_ix = Instruction(
    program_id=USDC_PROGRAM,
    accounts=[
        AccountMeta(src_token_account, is_signer=False, is_writable=True),
        AccountMeta(dest_token_account, is_signer=False, is_writable=True),
        AccountMeta(kp.pubkey(), is_signer=True, is_writable=False),
    ],
    data=data,
)

# Get fresh blockhash + build + sign + send in one shot
recent = solana.get_latest_blockhash(commitment=Confirmed)
msg = Message.new_with_blockhash([transfer_ix], kp.pubkey(), recent.value.blockhash)
tx = Transaction.new_unsigned(msg)
tx.sign([kp], recent.value.blockhash)

result = solana.send_transaction(tx)
print(f"\n✅ Sent ${AMOUNT} USDC")
print(f"   Tx: {result.value}")
