"""
Quick smoke test: run from the tally_integration/ directory.

Prerequisites:
  1. pip install solana solders requests
  2. .env populated (use the Connect Agent wizard in the Tally app, or copy .env.example)
     Required: TALLY_TG_TOKEN, TALLY_TG_CHAT_ID, TALLY_SESSION_SK, TALLY_VAULT_PUBKEY

Usage:
  cd warm-vault/tally_integration
  python run_test.py
"""
from warm_vault_auth import request_funding, check_session_balance, return_funds

print("Tally integration: smoke test")
print("=" * 50)

# 1. Request funding: sends Telegram notification, waits for card tap
session = request_funding(
    amount_usdc=2.0,
    task_description="Smoke test: verifying Tally integration",
)
print(f"\n✅ Funded: {session.funded_amount} USDC")
print(f"   Pubkey: {session.pubkey}")

# 2. Check on-chain balance
bal = check_session_balance(session.pubkey)
print(f"   SOL:    {bal['sol']:.6f}")
print(f"   USDC:   {bal['usdc']:.2f}")

# 3. Sweep residual back to vault
#    TALLY_VAULT_PUBKEY is read from .env automatically, no arg needed
sig = return_funds(session)
print(f"\n✅ Returned: {sig}")
