"""
Step 2 only: assumes session is already funded.
Run after run_test.py funded the session.
"""
import sys, base64, struct, os

from warm_vault_auth import solana, USDC_MINT_DEVNET, TokenAccountOpts
from solders.pubkey import Pubkey
from solders.keypair import Keypair as SoldersKeypair
from solders.instruction import AccountMeta, Instruction
from solders.message import Message
from solders.transaction import Transaction
from solana.rpc.commitment import Confirmed
from solana.rpc.types import TxOpts

DEST = "FiPGw32ZAQwfLovLtQQvRBKeFwrNPFNmBTcBpozAyUBK"
AMOUNT = 1.0
USDC_PROGRAM = Pubkey.from_string("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA")

raw_sk = base64.urlsafe_b64decode(os.getenv("TALLY_SESSION_SK") + "==")
kp = SoldersKeypair.from_seed(raw_sk[:32])

print(f"Session: {kp.pubkey()}")

# Source ATA
src_accounts = solana.get_token_accounts_by_owner_json_parsed(
    kp.pubkey(),
    opts=TokenAccountOpts(mint=Pubkey.from_string(USDC_MINT_DEVNET)),
    commitment=Confirmed,
).value
if not src_accounts:
    print("❌ No source USDC ATA"); sys.exit(1)
src = src_accounts[0].pubkey

# Dest ATA
dest_accounts = solana.get_token_accounts_by_owner_json_parsed(
    Pubkey.from_string(DEST),
    opts=TokenAccountOpts(mint=Pubkey.from_string(USDC_MINT_DEVNET)),
    commitment=Confirmed,
).value
if not dest_accounts:
    print("❌ No dest USDC ATA"); sys.exit(1)
dest = dest_accounts[0].pubkey

print(f"Source: {src}")
print(f"Dest:   {dest}")

# Build instruction
data = struct.pack("<BQ", 3, int(AMOUNT * 1e6))
ix = Instruction(
    program_id=USDC_PROGRAM,
    accounts=[
        AccountMeta(src, is_signer=False, is_writable=True),
        AccountMeta(dest, is_signer=False, is_writable=True),
        AccountMeta(kp.pubkey(), is_signer=True, is_writable=False),
    ],
    data=data,
)

# Fresh blockhash + build + sign + send in one shot
recent = solana.get_latest_blockhash(commitment=Confirmed)
msg = Message.new_with_blockhash([ix], kp.pubkey(), recent.value.blockhash)
tx = Transaction.new_unsigned(msg)
tx.sign([kp], recent.value.blockhash)

print(f"Sending... blockhash={recent.value.blockhash}")
result = solana.send_transaction(tx, opts=TxOpts(skip_preflight=True))
print(f"✅ Tx: {result.value}")
