# SKILL — Tally Agent Integration

## Trigger
Use whenever working with `tally_integration/` or when an agent needs to request on-chain funding from a user's Tally wallet.

## Summary
Gives the agent a **physical card tap** to authorize on-chain Solana spending. Agent requests a session wallet via Telegram notification → user taps card → agent executes transactions → sweeps residual back to vault.

The agent only ever holds a **session keypair** capped at `TALLY_MAX_SESSION` USDC. Master vault key never leaves the device.

---

## Setup (first time)

Use the **Connect Agent wizard** in the Tally app:
`Agents tab → AGENTS → NEW CONNECTION → complete 3 steps → copy .env block`

The wizard generates your Telegram credentials, deep-link secret, and session keypair in one flow and exports the complete `.env` block.

---

## Key facts

**Session key format:** Base64url encoded (Tally app export format).
Decode: `base64.urlsafe_b64decode(sk + "==")` → 64 bytes → `SoldersKeypair.from_seed(raw[:32])`

**Redirect URL:** Defaults to `https://lll.mk/tally/index.html` — no setup needed. Override with `TALLY_REDIRECT_URL` only if self-hosting.

**Deep-link signing:** HMAC-SHA256 over sorted `key=value` params (excluding `sig`), with Unix timestamp for anti-replay. Both `tg_bot.py` and the Tally app must share `TALLY_DEEP_LINK_SECRET`.

**RPC note:** Helius devnet (`devnet.helius-rpc.com`) returns expired blockhashes — always use `skip_preflight=True` with Helius, or use `api.devnet.solana.com`.

**USDC mint (devnet):** `4zMMC9srt5Ri5X14GAgXhaHii3GnPAEERYPJgZJDncDU`

---

## File inventory

```
tally_integration/
├── warm_vault_auth.py      # Core — request_funding, check_balance, return_funds, request_with_payment
├── tg_bot.py               # Telegram notifications with signed deep links
├── .env / .env.example     # Config
├── SETUP.md                # Full setup guide
├── run_test.py             # Smoke test — basic fund + sweep
├── run_x402_demo.py        # x402 demo — full paywalled endpoint flow
├── run_spend_3to2.py       # Full flow: fund + spend + sweep
├── run_send_only.py        # Send USDC (already funded session)
└── run_return_funds.py     # Sweep residual back to vault
```

---

## Integration (for an incoming agent)

1. Copy `tally_integration/` into your project (or add it to your Python path)
2. `pip install solana solders requests`
3. Populate `.env` — use the **Connect Agent wizard** in the Tally app (`Agents tab → AGENTS → NEW CONNECTION`) to generate a ready-to-paste `.env` block, or fill in `.env.example` manually
4. Call the three functions below — that's it

The `.env` the wizard generates includes `TALLY_VAULT_PUBKEY` (your master wallet address), so `return_funds()` needs no arguments.

---

## Core API

```python
from warm_vault_auth import request_funding, check_session_balance, return_funds, request_with_payment

# 1. Request funding — sends Telegram notification, blocks until card tap confirms on-chain
session = request_funding(amount_usdc=5.0, task_description="Research flight prices")

# 2. Check balance mid-task
bal = check_session_balance(session.pubkey)
# → {"sol": 0.004, "usdc": 4.2, "gas_low": False, "pubkey": "..."}

# 3. Sweep residual back to vault when done
#    TALLY_VAULT_PUBKEY is read from .env automatically
return_funds(session)

# Or pass the vault address explicitly if preferred
return_funds(session, master_vault_pubkey="<YOUR_VAULT_PUBKEY>")

# 4. x402 — hit a paywalled endpoint, handle 402 automatically
#    Detects X-Payment-Required: tally, funds a session, retries, sweeps back
result = request_with_payment(
    url="https://tally-signal.vercel.app/api/signal",
    amount_usdc=1.0,
    task_description="Fetch SOL/USDC market signal",
    return_funds_after=True,   # sweep remaining USDC back to vault after call
)
# result["ok"]      → True/False
# result["data"]    → parsed JSON response
# result["funded"]  → True if a card tap was triggered
# result["session"] → SessionWallet (or None if no payment was needed)
```

---

## SPL USDC transfer (solders-native)

```python
from solders.instruction import AccountMeta, Instruction
from solders.message import Message
from solders.transaction import Transaction
from solana.rpc.types import TxOpts
import struct

data = struct.pack("<BQ", 3, int(amount * 1e6))  # SPL Transfer instruction
ix = Instruction(
    program_id=Pubkey.from_string("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"),
    accounts=[
        AccountMeta(src_ata, is_signer=False, is_writable=True),
        AccountMeta(dest_ata, is_signer=False, is_writable=True),
        AccountMeta(kp.pubkey(), is_signer=True, is_writable=False),
    ],
    data=data,
)
recent = solana.get_latest_blockhash(commitment=Confirmed)
msg = Message.new_with_blockhash([ix], kp.pubkey(), recent.value.blockhash)
tx = Transaction.new_unsigned(msg)
tx.sign([kp], recent.value.blockhash)
result = solana.send_transaction(tx, opts=TxOpts(skip_preflight=True))
```

## SOL transfer (solders-native)

```python
from solders.system_program import TransferParams, transfer as sol_transfer
from solders.message import Message
from solders.transaction import Transaction as SoldersTransaction

sol_ix = sol_transfer(TransferParams(
    from_pubkey=session_pubkey,
    to_pubkey=vault_pubkey,
    lamports=int(amount * 1e9),
))
recent = solana.get_latest_blockhash(commitment=Confirmed)
msg = Message.new_with_blockhash([sol_ix], session_pubkey, recent.value.blockhash)
tx = SoldersTransaction.new_unsigned(msg)
tx.sign([session_kp], recent.value.blockhash)
solana.send_transaction(tx, opts=TxOpts(skip_preflight=True))
```

---

## Verified working (Apr 2026)

- `request_funding()` → Telegram notification → card tap → on-chain confirmation ✅
- SPL USDC transfer → confirmed on devnet ✅
- `return_funds()` → USDC + SOL swept → Telegram confirmation ✅
- Full E2E: fund $3 → send $2 → sweep $1 residual ✅
- HMAC-signed deep links → app shows VERIFIED badge ✅
- Connect Agent wizard → `.env` export → agent operational ✅
