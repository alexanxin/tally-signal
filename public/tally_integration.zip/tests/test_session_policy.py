"""
Unit tests for the time-bounded policy-tap helpers in warm_vault_auth.py.

Run directly with:

    python3 test_session_policy.py

Or via unittest discovery:

    python3 -m unittest test_session_policy.py

No pytest, no fixtures, no external deps. Mirrors the wallet-side coverage in
src/utils/sessionPolicy.test.ts so the two sides stay aligned on bounds and
edge cases.
"""

import unittest

from warm_vault_auth import (
    SessionWallet,
    _validate_ttl,
    is_session_active,
    MIN_TTL_SECONDS,
    MAX_TTL_SECONDS,
)


def _stub_session(expires_at):
    """Build a SessionWallet with the given expires_at and zero-cost defaults."""
    return SessionWallet(
        pubkey="StubPubkey",
        secret_key_bytes=b"\x00" * 32,
        funded_amount=1.0,
        currency="USDC",
        task_description="test",
        expires_at=expires_at,
    )


class ValidateTtlTests(unittest.TestCase):
    def test_none_passes_through(self):
        self.assertIsNone(_validate_ttl(None))

    def test_below_minimum_degrades_to_none(self):
        self.assertIsNone(_validate_ttl(0))
        self.assertIsNone(_validate_ttl(MIN_TTL_SECONDS - 1))

    def test_above_maximum_degrades_to_none(self):
        self.assertIsNone(_validate_ttl(MAX_TTL_SECONDS + 1))
        self.assertIsNone(_validate_ttl(1_000_000))

    def test_non_integer_degrades_to_none(self):
        # float, string, bool, anything non-int → None.
        self.assertIsNone(_validate_ttl(3600.5))  # type: ignore[arg-type]
        self.assertIsNone(_validate_ttl("3600"))  # type: ignore[arg-type]
        self.assertIsNone(_validate_ttl(True))    # type: ignore[arg-type]

    def test_accepts_boundary_and_interior_values(self):
        self.assertEqual(_validate_ttl(MIN_TTL_SECONDS), 60)
        self.assertEqual(_validate_ttl(MAX_TTL_SECONDS), 86_400)
        self.assertEqual(_validate_ttl(3600), 3600)


class IsSessionActiveTests(unittest.TestCase):
    def test_no_expiry_means_always_active(self):
        s = _stub_session(expires_at=None)
        self.assertTrue(is_session_active(s, now=999_999_999_999.0))

    def test_active_while_time_remains(self):
        s = _stub_session(expires_at=5000.0)
        self.assertTrue(is_session_active(s, now=4999.0))

    def test_inactive_after_deadline(self):
        s = _stub_session(expires_at=5000.0)
        self.assertFalse(is_session_active(s, now=5000.0))
        self.assertFalse(is_session_active(s, now=5001.0))


if __name__ == "__main__":
    unittest.main(verbosity=2)
