"""
Network-free unit tests for the correctness fixes (audit 2026-06-12).

Covers:
  - A1  funding-delta detection (no stale-balance bypass)
  - A6  EVEngine JIT clamp to MAX_SESSION_USDC
  - A2  deep-link signing canonicalization (_sign_params)
  - manifest truthfulness (request_with_payment present, version 0.2.0)

Run:  pytest          (from tally_integration/)
   or python3 -m pytest tests/
All on-chain calls are monkeypatched; nothing touches a network.
"""
import importlib
import hmac
import hashlib

import warm_vault_auth as w


# ── A6: EVEngine JIT clamp ──────────────────────────────────────────────────
def test_ev_jit_clamps_to_session_cap():
    r = w.EVEngine.calculate_request(estimated_ops=1, avg_cost_per_op=1000.0, risk_score=1.0)
    assert r["strategy"] == "JIT"
    assert r["amount"] <= w.MAX_SESSION_USDC


def test_ev_lump_sum_still_clamps():
    r = w.EVEngine.calculate_request(estimated_ops=10_000, avg_cost_per_op=1.0, risk_score=1.0)
    assert r["amount"] <= w.MAX_SESSION_USDC


# ── A1: funding-delta detection ─────────────────────────────────────────────
def test_poll_requires_delta_not_absolute(monkeypatch):
    # Wallet already holds 5 USDC (leftover from a prior session). A request for
    # 1 USDC must NOT auto-succeed on that stale balance.
    monkeypatch.setattr(w, "_get_token_balance", lambda *_a, **_k: 5.0)
    monkeypatch.setattr(w, "POLL_TIMEOUT", 1)
    monkeypatch.setattr(w, "POLL_INTERVAL", 1)
    funded, sig = w._poll_for_funding("Pubkey", expected_usdc=1.0, baseline_usdc=5.0)
    assert funded is False
    assert sig == ""


def test_poll_succeeds_on_real_delta(monkeypatch):
    # Balance rises from baseline 5.0 to 6.0 → a real +1 USDC funding.
    monkeypatch.setattr(w, "_get_token_balance", lambda *_a, **_k: 6.0)
    monkeypatch.setattr(w, "_get_latest_tx_signature", lambda *_a, **_k: "SIG123")
    monkeypatch.setattr(w, "POLL_TIMEOUT", 5)
    funded, sig = w._poll_for_funding("Pubkey", expected_usdc=1.0, baseline_usdc=5.0)
    assert funded is True
    assert sig == "SIG123"


# ── A2: deep-link signing canonicalization ──────────────────────────────────
def test_sign_params_is_sorted_hmac(monkeypatch):
    import tg_bot
    monkeypatch.setattr(tg_bot, "DEEP_LINK_SECRET", "s3cr3t")
    monkeypatch.setattr(tg_bot.time, "time", lambda: 1_700_000_000)
    signed = tg_bot._sign_params({"pubkey": "B", "amount": 2})
    # message is sorted key=value pairs excluding sig, including the ts stamp
    expected_msg = "&".join(f"{k}={v}" for k, v in sorted(
        {"pubkey": "B", "amount": 2, "ts": 1_700_000_000}.items()))
    expected_sig = hmac.new(b"s3cr3t", expected_msg.encode(), hashlib.sha256).hexdigest()
    assert signed["sig"] == expected_sig
    assert signed["ts"] == 1_700_000_000


def test_sign_params_noop_without_secret(monkeypatch):
    import tg_bot
    monkeypatch.setattr(tg_bot, "DEEP_LINK_SECRET", "")
    p = {"amount": 1}
    assert tg_bot._sign_params(p) == p  # unchanged, no sig added


# ── manifest truthfulness ───────────────────────────────────────────────────
def test_manifest_lists_x402_entrypoint_and_version():
    names = [t["name"] for t in w.SKILL_MANIFEST["tools"]]
    assert "request_with_payment" in names
    assert w.SKILL_MANIFEST["version"] == "0.2.0"
    funding = next(t for t in w.SKILL_MANIFEST["tools"] if t["name"] == "request_funding")
    assert "ttl" in funding["parameters"]
