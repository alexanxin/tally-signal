# Tally Agent Prompt

Paste this into any AI agent (Claude, GPT, Gemini, etc.) to give it access to
the Tally funding skill. The agent will use `request_with_payment()` to hit the
paywalled signal endpoint, handle the 402 automatically, and return the result.

---

## System prompt (add to agent config)

```
You are a trading research agent with access to a paywalled market signal API.
You use the Tally skill to pay for API access on-chain — no credit cards, no
API keys. Payment happens via a physical card tap on the user's phone.

Your working directory contains the Tally integration skill:
  warm_vault_auth.py  — request_funding, return_funds, request_with_payment
  tg_bot.py           — Telegram notification bridge
  .env                — your credentials (TALLY_SESSION_SK, TALLY_TG_TOKEN, etc.)

When you need to access a paywalled endpoint:
1. Import request_with_payment from warm_vault_auth
2. Call it with the URL — it handles the 402 automatically
3. Wait for the user to tap their card (you'll see polling logs)
4. Use the returned data to complete your task
5. Funds are swept back automatically (return_funds_after=True by default)

Never call request_funding() directly unless you need a persistent session for
multiple operations. For single API calls, always use request_with_payment().
```

---

## User message to trigger the x402 demo

```
Fetch a market signal for SOL/USDC from the Tally signal API at
https://tally-signal.vercel.app/api/signal

Use request_with_payment() from warm_vault_auth.py to handle the payment.
Fund with 1 USDC. After you get the signal, tell me:
- The direction (bullish/bearish)
- Entry, target, and stop loss prices
- The R:R ratio
- Whether funding was required
```

---

## What the agent should do (expected flow)

1. Write and execute Python code:
   ```python
   import sys
   sys.path.insert(0, "/path/to/tally_integration")
   from warm_vault_auth import request_with_payment

   result = request_with_payment(
       url="https://tally-signal.vercel.app/api/signal",
       amount_usdc=1.0,
       task_description="Fetch SOL/USDC market signal",
       return_funds_after=True,
   )
   print(result)
   ```

2. The code hits the endpoint → receives 402 → triggers Telegram notification
3. **You tap your card in the Tally app**
4. Agent polls until on-chain confirmation (up to 120s)
5. Agent retries the endpoint with X-Tally-Session header → gets signal
6. Agent reports the signal + sweeps remaining USDC back to vault

---

## Notes

- The `.env` file in `tally_integration/` must be configured before running.
  Use the Connect Agent wizard in the Tally app to generate it automatically.
- If the agent has code execution (Claude Code, OpenClaw, GPT with Code
  Interpreter), it can run the Python directly.
- If the agent doesn't have code execution, use `run_x402_demo.py` instead:
  ```bash
  cd tally_integration
  python run_x402_demo.py --url https://tally-signal.vercel.app/api/signal
  ```
- Signal server must be deployed before testing against the live URL.
  For local testing: `cd tally-signal && npm run dev` (runs on localhost:3000).
