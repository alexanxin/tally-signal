# Tally Agent Prompt

Paste this into any AI agent (Claude, GPT, Gemini, etc.) to give it access to
the Tally funding skill. Tally lets an agent spend real on-chain USDC that a
person authorizes with a physical card tap. No credit cards, no API keys, and
the master vault key never leaves the user's phone.

---

## Two ways an agent gets funded

Tally supports two authorization models. A given agent is set up with one of them.

**1. Ask each time (available now).** For a single task the agent asks for funds,
the user gets a Telegram notification and taps their card once, and a capped
session wallet is funded for that task. The agent spends from the session wallet
and the residual sweeps back to the vault. `request_with_payment()` does this end
to end, including the 402 handshake.

**2. Standing budget, pay direct (available).** The user pre-authorizes a
capped, time-boxed budget once with a single card tap. The agent then pays
merchants straight from the vault within that budget, with no further taps and no
waiting. Two properties make this safer than holding funds:

- The money stays in the vault until the exact moment of a payment. Nothing is
  parked in a hot wallet.
- The budget's expiry is a hard cutoff. Once the window closes the next payment
  is rejected on-chain, and the remaining cap simply stays in the vault.

The agent already holds the right key for this (its session key is the authorized
delegate), so no new credentials are needed. If no budget exists yet, call
`request_budget(amount, ttl, reason)` to propose one (the user approves with a
card tap). Then use `budget_status()` to read the remaining cap,
`pay_from_budget(payee, amount)` to pay a payee directly, or
`request_with_payment(url, source="budget")` for paywalled APIs.

---

## System prompt (add to agent config)

```
You are a trading research agent with access to a paywalled market signal API.
You use the Tally skill to pay for API access on-chain. No credit cards, no API
keys. Payment is authorized by a physical card tap on the user's phone.

Your working directory contains the Tally integration skill:
  warm_vault_auth.py  : request_with_payment, request_funding, return_funds
  tg_bot.py           : Telegram notification bridge
  .env                : your credentials (TALLY_SESSION_SK, TALLY_TG_TOKEN, etc.)

You may be funded one of two ways:
  - Ask each time: you trigger a card tap per task (the default today).
  - Standing budget: the user pre-authorized a capped, time-boxed budget, so you
    spend without a tap until it runs out or expires (use source="budget").

When you need to access a paywalled endpoint (ask-each-time):
1. Import request_with_payment from warm_vault_auth
2. Call it with the URL. It handles the 402 automatically
3. Wait for the user to tap their card (you will see polling logs)
4. Use the returned data to complete your task
5. Funds are swept back automatically (return_funds_after=True by default)

Never call request_funding() directly unless you need a persistent session for
multiple operations. For single API calls, always use request_with_payment().
```

---

## User message to trigger the x402 demo

```
Fetch a market signal for SOL/USDC from the Tally signal API at
https://tally-signal.vercel.app/api/signal

Use request_with_payment() from warm_vault_auth.py to handle the payment.
Fund with 1 USDC. After you get the signal, tell me:
- The direction (bullish/bearish)
- Entry, target, and stop loss prices
- The R:R ratio
- Whether funding was required
```

---

## What the agent should do (expected flow, ask-each-time)

1. Write and execute Python code:
   ```python
   import sys
   sys.path.insert(0, "/path/to/tally_integration")
   from warm_vault_auth import request_with_payment

   result = request_with_payment(
       url="https://tally-signal.vercel.app/api/signal",
       amount_usdc=1.0,
       task_description="Fetch SOL/USDC market signal",
       return_funds_after=True,
   )
   print(result)
   ```

2. The code hits the endpoint, receives 402, triggers a Telegram notification
3. **You tap your card in the Tally app**
4. Agent polls until on-chain confirmation (up to 120s)
5. Agent retries the endpoint with X-Tally-Session header, gets the signal
6. Agent reports the signal and sweeps remaining USDC back to the vault

With a standing budget (source="budget") steps 2 to 4 disappear: the agent pays the
endpoint directly from the vault within the pre-authorized cap, then retries with
the on-chain proof. No card tap, no polling.

---

## Notes

- The `.env` file in `tally_integration/` must be configured before running.
  Use the Connect Agent wizard in the Tally app to generate it automatically.
- If the agent has code execution (Claude Code, OpenClaw, GPT with Code
  Interpreter), it can run the Python directly.
- If the agent doesn't have code execution, use `run_x402_demo.py` instead:
  ```bash
  cd tally_integration
  python run_x402_demo.py --url https://tally-signal.vercel.app/api/signal
  ```
- Signal server must be deployed before testing against the live URL.
  For local testing: `cd tally-signal && npm run dev` (runs on localhost:3000).
