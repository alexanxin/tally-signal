import sys, os, base64

from warm_vault_auth import return_funds, _get_token_balance, USDC_MINT_DEVNET, SessionWallet
from solders.keypair import Keypair as SoldersKeypair

raw_sk = base64.urlsafe_b64decode(os.getenv("TALLY_SESSION_SK") + "==")
kp = SoldersKeypair.from_seed(raw_sk[:32])
pubkey = str(kp.pubkey())
secret_bytes = bytes(kp)

bal_usdc = _get_token_balance(pubkey, USDC_MINT_DEVNET)
session = SessionWallet(pubkey=pubkey, secret_key_bytes=secret_bytes, funded_amount=bal_usdc)
print(f"Session: {pubkey}, USDC: {bal_usdc}")

VAULT = "FiPGw32ZAQwfLovLtQQvRBKeFwrNPFNmBTcBpozAyUBK"
result = return_funds(session, VAULT)
print(f"Result: {result}")
